
from distutils.core import setup

setup(
    name = 'Testing_p2121',
    packages = ['.'],
    version = '0.1.0',
    description = 'Test',
    author = 'Ahmet Yıldırır',
    author_email = 'ahmetyildirir1@gmail.com',
    url = 'https://github.com/Ahmetyldrr/mypackage_test',
    keywords = ['TAG1', 'TAG2'],
    classifiers = [],
)
